import UIKit

// Листинг 2.1
let someText = "Я учу Свифт"

// Листинг 2.2
// создаем переменную orksName с неявным определением типа String
var orksName = "Рухард"
// создаем переменную elfsName с явным определением типа String
var elfsName: String = "Эанор"
// изменим значения переменных
orksName = "Гомри"
elfsName = "Лиасель"

// Листинг 2.3
//let firstHobbitsName //ОШИБКА

// Листинг 2.4
// неявно определим параметр целочисленного типа данных
var variableOne = 23
// явно определим параметр целочисленного типа данных
// после чего передадим ему значение другого переметра в качестве первоначального
let variableOneCopy: Int = variableOne
print(variableOneCopy)
// изменим значение в первой переменной
variableOne = 25
print(variableOneCopy)
print(variableOne)

// Листинг 2.5
// объявим переменную знакового целочисленного типа и присвоим ей значение
var signedNum: Int = -32
// объявим константу беззнакового целочисленного типа и проинициализируем ей значение
let unsignedNum: UInt = 128

// Листинг 2.6
// минимальное значение параметра типа Int8
let minInt8 = Int8.min
// максимальное значение параметра типа Int8
let maxInt8 = Int8.max
// минимальное значение параметра типа UInt8
let minUInt8 = UInt8.min
// максимальное значение параметра типа UInt8
let maxUInt8 = UInt8.max

// Листинг 2.7
// дробное число типа Float с явным указанием типа
let numFloat: Float = 104.3
// дробное число типа Double с явным указанием типа
let numDouble: Double = 8.36
// дробное число типа Double с неявным указанием типа
let someNumber = 8.36

// Листинг 2.8
// целочисленные константы
let numOne = 19
let numTwo = 4
// константы, имеющие тип числа с плавающей точкой
let numThree = 3.13
let numFour = 1.1

// Листинг 2.9
// операция сложения
let sum = numOne + numTwo
// операция вычитания
let diff = numOne - numTwo
// операция умножения
let mult = numOne * numTwo
// операция деления
let qo = numOne / numTwo

// Листинг 2.10
// операция сложения
let sumD = numThree + numFour
// операция вычитания
let diffD = numThree - numFour
// операция умножения
let multD = numThree * numFour
// операция деления
let qoD = numThree / numFour

// Листинг 2.11
// операция получения остатка от деления
let res1 = numOne % numTwo
let res2 = -numOne % numTwo
let res3 = numOne % -numTwo

// Листинг 2.12
// дробные константы
let firstFloat: Float = 3.14
let secondFloat: Float = 1.01
// операция получения остатка от деления
let result1 = firstFloat.truncatingRemainder(dividingBy: secondFloat)
let result2 = -firstFloat.truncatingRemainder(dividingBy: secondFloat)
let result3 = firstFloat.truncatingRemainder(dividingBy: -secondFloat)

// Листинг 2.13
// переменная типа Int
let numberInt = 19
// переменная типа Double
let numberDouble = 3.13
// операция перемножения чисел
let resD = Double(numberInt) * numberDouble
let resI = numberInt * Int(numberDouble)

// Листинг 2.14
// переменная типа Int
var count = 19
// прибавим к ней произвольное число
count += 5
/* эта операция аналогична выражению
 count = count + 5 */
// умножим его на число 3
count *= 3
/* эта операция аналогична выражению
 count = count * 3 */
// вычтем из него число 3
count -= 3
/* эта операция аналогична выражению
 count = count - 3 */
// найдем остаток от деления на 8
count %= 8
/* эта операция аналогична выражению
 count = count % 8 */

// Листинг 2.15
// переменная типа Int
var itterationValue = 19
// увеличим ее значение с использованием арифметической операции сложения
itterationValue = itterationValue + 1
// увеличим ее значение с использованием составного оператора присваивания
itterationValue += 1

// Листинг 2.16
// 17 в десятичном виде
let decimalInteger = 17
// 17 в двоичном виде
let binaryInteger = 0b10001
// 17 в восьмиричном виде
let octalInteger = 0o21
// 17 в шестнадцатеричном виде
let hexadecimalInteger = 0x11

// Листинг 2.17
// десятичное число
let decimalDouble = 12.1875
// десятичное число с экспонентой
// соответствует выражению exponentDouble = 1.21875*10^1
let exponentDouble  = 1.21875e1
// шестнадцатиричное число с экспонентой
// соответствует выражению hexadecimalDouble = 0xC.3*2^0
let hexadecimalDouble = 0xC.3p0

// Листинг 2.18
let number = 1_000_000
let nextNumber = 1000000

// Листинг 2.19
var myWallet: Double = 0
let incomeAfterOperation: Double = 0.1

// Листинг 2.20
myWallet += incomeAfterOperation
print(myWallet)
myWallet += incomeAfterOperation
print(myWallet)
myWallet += incomeAfterOperation
print(myWallet)

// Листинг 2.21
import Foundation
var decimalWallet: Decimal = 0
let income: Decimal = 0.1
decimalWallet += income
print(decimalWallet)
decimalWallet += income
print(decimalWallet)
decimalWallet += income
print(decimalWallet)

// Листинг 2.22
let char: Character = "a"
print(char)

// Листинг 2.23
// константа типа String
// тип данных задается явно
let stringOne: String = "Dragon"

// Листинг 2.24
let language = "Swift"
let version = "5"

// Листинг 2.25
// с помощью пустого строкового литерала
var emptyString = ""
// с помощью инициализатора типа String
var anotherEmptyString = String()

// Листинг 2.26
let longString = """
Это многострочный
строковый литерал
"""

// Листинг 2.27
// инициализация строкового значения
let notEmptyString = String("Hello, Troll!")

// Листинг 2.28
// константа типа Double
let someDoubleNumber = 74.22
// строка, созданная на основе константы типа Double
let someStringNumber = String(someDoubleNumber)

// Листинг 2.29
// переменная типа String
let name = "Дракон"
// константа типа String с использованием интерполяции
let hello = "Привет, меня зовут \(name)"
// интерполяция с использованием выражения
let meters: Double = 10
let text = "Моя длина \(meters * 3.28) фута"
// выведем значения на консоль
print(hello)
print(text)

// Листинг 2.30
// константа типа String
let firstText = "Мой вес"
// переменная типа Double
let weight = 12.4
// константа типа String
let secondText = " тонны"
// конкатенация строк при инициализации значения новой переменной
let resultText = firstText + String(weight) + secondText
print(resultText)

// Листинг 2.31
let firstString = "Swift"
let secondString = "Objective-C"
let anotherString = "Swift"
firstString == secondString
firstString == anotherString

// Листинг 2.32
let myCharOverUnicode: Character = "\u{041A}"
myCharOverUnicode

// Листинг 2.33
let stringOverUnicode = "\u{41C}\u{438}\u{440}\u{20}\u{412}\u{430}\u{43C}\u{21}"
stringOverUnicode

// Листинг 2.34
// константа с неявно заданным логическим типом
let isDragon = true
// константа с явно заданным логическим типом
let isKnight: Bool = false

// Листинг 2.35
// логическая переменная
isDragon
// конструкция условия
if isDragon {
    print("Привет, Дракон!")
} else {
    print("Привет, Тролль!")
}

// Листинг 2.36
let someBool = true
// инвертируем значение
!someBool
someBool

// Листинг 2.37
let firstBool = true, secondBool = true, thirdBool = false
// группируем различные условия
let oneAnd = firstBool && secondBool
let twoAnd = firstBool && thirdBool
let threeAnd = firstBool && secondBool && thirdBool

// Листинг 2.38
let oneOr = firstBool || secondBool
let twoOr = firstBool || thirdBool
let threeOr = secondBool || thirdBool

// Листинг 2.39
let resultBool = firstBool && secondBool || thirdBool
let resultAnotherBool = thirdBool || firstBool && firstBool

// Листинг 2.40
let resBool = firstBool && (secondBool || thirdBool)
let ersAnotherBool = (secondBool || (firstBool && thirdBool)) && thirdBool

// Листинг 2.41
// утверждение "1 больше 2"
1 > 2
// вернет false, так как оно ложно
// утверждение "2 не равно 2"
2 != 2
// вернет false, так как оно ложно
// Утверждение "1 плюс 1 меньше 3"
(1 + 1) < 3
// вернет true, так как оно истинно
// Утверждение "5 больше или равно 1"
5 >= 1
// вернет true, так как оно истинно

