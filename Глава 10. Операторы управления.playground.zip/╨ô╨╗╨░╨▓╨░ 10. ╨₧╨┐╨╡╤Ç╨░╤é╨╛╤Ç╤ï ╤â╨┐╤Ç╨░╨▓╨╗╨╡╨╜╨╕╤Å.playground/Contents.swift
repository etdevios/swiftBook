import UIKit

// Листинг 10.1
let strName = "Дракон"
let strYoung = "молод"
let strOld = "стар"
let strEmpty = " "

var dragonAge = 230
assert( dragonAge <= 235, strName + strEmpty + strOld)
assert( dragonAge >= 225, strName + strEmpty + strYoung)
print("Программа успешно завершила свою работу")

// Листинг 10.2
//var dragonAge = 220
assert( dragonAge <= 235, strName + strEmpty + strOld)
assert( dragonAge >= 225, strName + strEmpty + strYoung)
print("Программа успешно завершила свою работу")

// Листинг 10.3
// переменная типа Bool
var logicVar = true
// проверка значения переменной
if logicVar == true {
    print("Переменная logicVar истинна")
}

// Листинг 10.4
if logicVar {
    print("Переменная logicVar истинна")
}

// Листинг 10.5
logicVar = false
if logicVar {
    print("Переменная logicVar истинна")
}

// Листинг 10.6
var intVar = 1
//if intVar {
//
//}

// `Листинг 10.7
logicVar = false
// полная форма проверки на отрицание
if logicVar == false {
    print("Переменная logicVar ложна")
}
// сокращенная форма проверки на отрицание
if !logicVar {
    print("Переменная logicVar вновь ложна")
}

// Листинг 10.8
// переменная типа Bool
//var logicVar = false
// проверка значения переменной
if logicVar {
    print("Переменная logicVar истинна")
} else {
    print("Переменная logicVar ложна")
}

// Листинг 10.9
let a = 1054
let b = 952
if a+b > 1000 {
    print("Сумма больше 1000")
} else {
    print("Сумма меньше или равна 1000")
}

// Листинг 10.10
// переменные типа Bool
var firstLogicVar = true
var secondLogicVar = false
// проверка значения переменных
if firstLogicVar || secondLogicVar {
    print("Одна или две переменные истинны")
} else {
    print("Обе переменные ложны")
}

// Листинг 10.11
if firstLogicVar || secondLogicVar {
    if firstLogicVar && secondLogicVar {
        print("Обе переменные истинны")
    } else {
        print("Только одна из переменных истинна")
    }
} else {
    print("Обе переменные ложны")
}

// Листинг 10.12
if firstLogicVar && secondLogicVar {
    print("Обе переменные истинны")
} else {
    if firstLogicVar || secondLogicVar {
        print("Только одна из переменных истинна")
    } else {
        print("Обе переменные ложны")
    }
}

// Листинг 10.13
// проверка значения переменных
if firstLogicVar && secondLogicVar {
    print("Обе переменные истинны")
} else if firstLogicVar || secondLogicVar {
    print("Одна из переменных истинна")
} else {
    print("Обе переменные ложны")
}

// Листинг 10.14
firstLogicVar = true
secondLogicVar = true
if firstLogicVar || secondLogicVar {
    print("Одна из переменных истинна")
} else if firstLogicVar && secondLogicVar {
    print("Обе переменные истинны")
} else {
    print("Обе переменные ложны")
}

// Листинг 10.15
// количество жильцов в доме
var tenantCount = 6
// стоимость аренды на человека
var rentPrice = 0
// определение цены на одного человека в соответствии с условием
if tenantCount < 5 {
    rentPrice = 1000
} else if tenantCount >= 5 && tenantCount <= 7 {
    rentPrice = 800
} else {
    rentPrice = 500
}
// вычисление общей суммы средств
var allPrice = rentPrice * tenantCount

// Листинг 10.16
if (..<5).contains(tenantCount) {
    rentPrice = 1000
} else if (5...7).contains(tenantCount) {
    rentPrice = 800
} else if (8...).contains(tenantCount) {
    rentPrice = 500
}

// Листинг 10.17
let myA = 1
let myB = 2
// сравнение значений констант
myA <= myB ? print("А меньше или равно В") : print("А больше В")

// Листинг 10.18
// переменная типа Int
var height = 180
// переменная типа Bool
var isHeader = true
// вычисление значения константы
let rowHeight = height + (isHeader ? 20 : 10)
// вывод значения переменной
rowHeight

if let a1 = Int("43"), let b1 = Int("45"), a1 < b1 {
    print("a < b")
}

// Листинг 10.19
// оценка
let userMark = 4
if userMark == 1 {
    print("Единица на экзамене! Это ужасно!")
} else if userMark == 2 {
    print("С двойкой ты останешься на второй год!")
} else if userMark == 3 {
    print("Ты плохо учил материал в этом году!")
} else if userMark == 4 {
    print("Неплохо, но могло быть и лучше")
} else if userMark == 5 {
    print("Бесплатное место в университете тебе обеспечено!")
} else {
    print("Переданы некорректные данные об оценке")
}

// Листинг 10.20
// переменная для хранения сообщения
let message: String

switch userMark {
case 1:
    message = "Единица на экзамене! Это ужасно!"
case 2:
    message = "С двойкой ты останешься на второй год!"
case 3:
    message = "Ты плохо учил материал в этом году!"
case 4:
    message = "Неплохо, но могло быть и лучше"
case 5:
    message = "Бесплатное место в университете тебе обеспечено!"
default:
    message = "Переданы некорректные данные об оценке"
}
print(message)

// Листинг 10.21
switch userMark {
case 1..<3:
    print("Экзамен не сдан")
case 3:
    print("Требуется решение дополнительного значения")
case 4...5:
    print("Экзамен сдан")
default:
    assert(false, "Указана некорректная оценка")
}

// Листинг 10.22
let answer: (code: Int, message: String) = (code: 404, message: "Page not found")

// Листинг 10.23
/* switch answer {
case (100..<400, _):
    print( answer.message )
case (400..<500, _):
    assert( false, answer.message )
default:
    print( "Получен некорректный ответ" )
}
 */

// Листинг 10.24
let dragonCharacteristics: (color: String, weight: Float) = ("красный", 1.4)
switch dragonCharacteristics {
case ("зеленый", 0..<2):
    print("Вольер № 1")
case ("красный", 0..<2):
    print("Вольер № 2")
case ("зеленый", 2...), ("красный", 2...):
    print("Вольер № 3")
default:
    print("Дракон не может быть принят в стаю")
}

// Листинг 10.25
var dragonCount = 3
switch dragonCharacteristics {
case ("зеленый", 0..<2):
    print("Вольер № 1")
case ("красный", 0..<2):
    print("Вольер № 2")
case ("зеленый", 2...) where dragonCount < 5,
    ("красный", 2...) where dragonCount < 5:
    print("Вольер № 3")
default:
    print("Дракон не может быть принят в стаю")
}

// Листинг 10.26
switch dragonCharacteristics {
case ("зеленый", 0..<2):
    print("Вольер № 1")
case ("красный", 0..<2):
    print("Вольер № 2")
case ("зеленый", 2...) where
    dragonCharacteristics.weight.truncatingRemainder(dividingBy: 1) == 0 && dragonCount < 5,
    ("красный", 2...) where
    dragonCharacteristics.weight.truncatingRemainder(dividingBy: 1) == 0 && dragonCount < 5:
    print("Вольер № 3")
default:
    print("Дракон не может быть принят в стаю")
}

// Листинг 10.27
switch dragonCharacteristics {
case ("зеленый", 0..<2):
    print("Вольер № 1")
case ("красный", 0..<2):
    print("Вольер № 2")
case ("зеленый", let weight) where
    weight > 2
    && dragonCount < 5,
    ("красный", let weight) where
    weight > 2
    && dragonCount < 5:
    print("Вольер № 3")
default:
    print("Дракон не может быть принят в стаю")
}

// Листинг 10.28
switch dragonCharacteristics {
case ("зеленый", 0..<2):
    print("Вольер № 1")
case ("красный", 0..<2):
    print("Вольер № 2")
case ("зеленый", let weight) where
    weight > 2
    && weight.truncatingRemainder(dividingBy: 1) == 0
    && dragonCount < 5,
    ("красный", let weight) where
    weight > 2
    && weight.truncatingRemainder(dividingBy: 1) == 0
    && dragonCount < 5:
    print("Вольер № 3")
default:
    print("Дракон не может быть принят в стаю")
}

// Листинг 10.29
switch dragonCharacteristics {
case ("зеленый", 0..<2):
    print("Вольер № 1")
case ("красный", 0..<2):
    print("Вольер № 2")
case let (color, weight) where
    (color == "зеленый" || color == "красный")
    && weight > 2
    && weight.truncatingRemainder(dividingBy: 1) == 0
    && dragonCount < 5:
    print("Вольер № 3")
default:
    print("Дракон не может быть принят в стаю")
}

// Листинг 10.30
let someInt = 12
switch someInt {
case 1...:
    print("Больше 0")
case ..<0:
    print("Меньше 0")
default:
    break
}

// Листинг 10.31
let level: Character = "Б"
// определение уровня готовности
switch level {
case "А":
    print("Выключить все электрические приборы")
    fallthrough
case "Б":
    print("Закрыть входные двери и окна")
    fallthrough
case "В":
    print("Соблюдать спокойствие")
default:
    break
}


// Листинг 10.32
// начальное значение
var i = 1
// хранилище результата сложения
var resultSum = 0
// цикл подсчета суммы
while i <= 10 {
    resultSum += 1
    i += 1
}
resultSum

// Листинг 10.33
// начальное знчение
var y = 1
// хранилище результата сложения
var result = 0
// цикл для подсчета суммы
repeat {
    result += y
    y += 1
} while y <= 10
result

// Листинг 10.34
var x = 0
var sum = 0
while x <= 10 {
    x += 1
    if x % 2 == 1 {
        continue
    }
    sum += x
}
sum

// Листинг 10.35
let lastNum = 54
var currentNum = 1
var sumOfInts = 0

while currentNum <= lastNum {
    sumOfInts += currentNum
    if sumOfInts > 450 {
        print("Хранилище заполнено. Последнее обработанное число - \(currentNum)")
        break
    }
    currentNum += 1
}

// Листинг 10.36
// массив целых чисел
let numArray: Array<Int> = [1, 2, 3, 4, 5]
// в данной переменной будет храниться сумма элементов массива numArray
var result1: Int = 0
// цикл подсчета суммы
for number in numArray {
    result1 += number
}
result1

// Листинг 10.37
for number in 1...5 {
    print(number)
}

// Листинг 10.38
for number in "Swift" {
    print(number)
}

// Листинг 10.39
// внешняя переменная
var myChar = "a"
// внешняя константа
let myString = "Swift"
// цикл использует связанный переметр с именем, уже используемым глобальной переменной
for myChar in myString {
    // локальная констаната вне цикла уже существует константа с таким именем
    let myString = "Char is"
    print("\(myString) \(myChar)")
}
myChar
myString

// Листинг 10.40
for _ in 1...3 {
    print("Повторяющаяся строка")
}

// Листинг 10.41
var countriesAndBloks = ["Россия": "СНГ", "Франция": "ЕС"]
for (countryName, orgName) in countriesAndBloks {
    print("\(countryName) вступила в \(orgName)")
}

// Листинг 10.42
for (countryName, _) in countriesAndBloks {
    print("страна - \(countryName)")
}
for (_, orgName) in countriesAndBloks {
    print("организация - \(orgName)")
}

// Листинг 10.43
countriesAndBloks = ["Россия": "ЕАЭС", "Франция": "ЕС"]
for countryName in countriesAndBloks.keys {
    print("страна - \(countryName)")
}
for orgName in countriesAndBloks.values {
    print("организация - \(orgName)")
}

// Листинг 10.44
print("Несколько фактов обо мне:")
let myMusicStyles = ["Rock",  "Jazz", "Pop"]
for (index, musicName) in myMusicStyles.enumerated() {
    print("\(index + 1). Я люблю \(musicName)")
}

// Листинг 10.45
// коллекция элементов от 1 до 10 с шагом 3
let intNumbers = [1, 4, 7, 10]
for element in intNumbers {
    // код, обрабатывающий очередной элемент
}

// Листинг 10.46
for i in stride(from: 1, through: 10, by: 3) {
    // тело оператора
    print(i)
}

// Листинг 10.47
for i in stride(from: 1, to: 10, by: 3) {
    // тело оператора
    print(i)
}

// Листинг 10.48
var result2 = 0
for i in stride(from: 1, through: 1000, by: 2) {
    result2 += i
}
result2

// Листинг 10.49
var result3 = 0
for i in 1...10 where i % 2 == 0 {
    result3 += i
}
result3

// Листинг 10.50
var isRun = true

// вариант 1
if isRun {
    for i in 1...10 {
        // тело оператора
    }
}
// вариант 2
for i in 1...10 where isRun {
    // тело оператора
}

// Листинг 10.51
// словарь с результатами игр
let resultsOfGames = ["Red Wings": ["2:1", "2:3"], "Capitals": ["3:6", "5:5"], "Penguins": ["3:3", "1:2"]]
// обработка словаря
for (teamName, results) in resultsOfGames {
    // обработка массива результатов игр
    for oneResult in results {
        print("Игра с \(teamName) - \(oneResult)")
    }
}

// Листинг 10.52
for i in 1...10 {
    if i % 2 == 0 {
        continue
    } else {
        print(i)
    }
}

// Листинг 10.53
import Foundation
for i in 1... {
    let randNum = Int(arc4random_uniform(100))
    if randNum == 5 {
        print("Итерация номер \(i)")
        break
    }
}

// Листинг 10.54
for i in 1... {
    let randNum = Array<Int>(0...100).randomElement()
    if randNum == 5 {
        print("Итерация номер \(i)")
        break
    }
}

// Листинг 10.55
mainLoop: for i in 1...5 {
    for y in i...5 {
        if y == 4 && i == 2 {
            break mainLoop
        }
        print("\(i) - \(y)")
    }
}

// Листинг 10.56
// неверный подход
/* switch userStatus {
case .online:
    // ...
default:
    // ...
}
*/
// лучше провести проверку с помощью if
/* if userStatus == .online {
    // ...
} else {
    // ...
}
*/

// Листинг 10.57
// неверный подход
/* switch userStatus {
case _ where a > b:
    // ...
}
*/
// лучше провести проверку с помощью if
/* if a > b {
    // ...
}
*/

